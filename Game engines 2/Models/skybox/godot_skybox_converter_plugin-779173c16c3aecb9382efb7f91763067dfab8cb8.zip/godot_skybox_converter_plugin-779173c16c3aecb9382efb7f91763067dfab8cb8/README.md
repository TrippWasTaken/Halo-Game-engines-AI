# godot_skybox_converter_plugin
A simple tool to import skyboxes (cubemaps) from Internet resources sites to use in Godot Engine.
