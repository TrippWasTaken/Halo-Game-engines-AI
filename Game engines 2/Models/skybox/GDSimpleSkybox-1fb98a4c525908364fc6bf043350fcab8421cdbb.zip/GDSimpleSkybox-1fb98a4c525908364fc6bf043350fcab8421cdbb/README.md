# GDSimpleSkybox
Simple skybox for Godot is a tool script and have six sides where you can apply texture.

![Alt text](https://github.com/Chaosus/GDSimpleSkybox/blob/master/screenshot.png)

Note: No sky textures is included - you can find them in internet

# What ? PanoramaSky is not enought ?
PanoramaSky is for hdr(cubemaps). This script allows you to construct skybox directly from six textures. I found that internet contains a lot of these single images, so this script could simplify the life for developers a bit.

# How to use
Insert the Skybox.tscn to your scene and setup six textures to it, after this restart scene and the resulted skybox will shows, scale it how you like, and enjoy !
